"""
`Live
<https://docs.rs/pauli_tracker/latest/pauli_tracker/tracker/live/struct.Live.html>`_\\
<`Map
<https://docs.rs/pauli_tracker/latest/pauli_tracker/collection/type.Map.html>`_>
"""

from pauli_tracker._lib.live.map import Live
