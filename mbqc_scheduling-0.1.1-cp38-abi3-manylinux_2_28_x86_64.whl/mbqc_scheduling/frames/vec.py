"""
`Frames
<https://docs.rs/pauli_tracker/latest/pauli_tracker/tracker/frames/struct.Frames.html>`_\\
<`NaiveVector
<https://docs.rs/pauli_tracker/latest/pauli_tracker/collection/struct.NaiveVector.html>`_>
"""

from mbqc_scheduling._lib.frames.vec import Frames
