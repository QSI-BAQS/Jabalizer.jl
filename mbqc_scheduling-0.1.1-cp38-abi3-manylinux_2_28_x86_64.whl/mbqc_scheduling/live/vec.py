"""
`Live
<https://docs.rs/pauli_tracker/latest/pauli_tracker/tracker/live/struct.Live.html>`_\\
<`NaiveVector
<https://docs.rs/pauli_tracker/latest/pauli_tracker/collection/struct.NaiveVector.html>`_>
"""

from mbqc_scheduling._lib.live.vec import Live
